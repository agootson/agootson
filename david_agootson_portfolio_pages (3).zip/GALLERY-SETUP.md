# Gallery setup

## Daily photo workflow
1. Upload your image to your website hosting (or an image/CDN service).
2. Duplicate the `.memory` template card in `gallery.html`.
3. Replace `YOUR-IMAGE-URL` with the image URL.
4. Replace `Your photo title` with your title.
5. Replace the description with your own caption.
6. Update the download link to the same image URL.
7. Put newest photos first.

## Compact Samsung-style layout
The gallery uses CSS multi-column masonry (`columns`) with very small gaps. This keeps photos compact and lets visitors browse many daily pictures quickly. It automatically changes to fewer columns on smaller screens.

## Viewing and downloading
Clicking a photo opens a larger lightbox with its description and a Download Photo button.

Note: some browsers/hosting configurations may open an image instead of forcing a download. To guarantee forced downloads, serve the image with the appropriate `Content-Disposition: attachment` response from your server.

## Comments
For shared comments visible to everyone, use Giscus or another hosted comment provider. A static HTML textarea cannot persist comments for other visitors.
